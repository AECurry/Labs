//
//  CalendarViewModel.swift
//  TSMAMountainlandCalendar
//
//  Created by AnnElaine on 11/7/25.
//

import Foundation
import Observation

// MARK: - Calendar ViewModel
/// CalendarViewModel: Provides calendar/month schedule data.
/// Uses the real APIController to fetch calendar entries from the server.
@Observable
class CalendarViewModel {
    // MARK: - State
    var calendarEntries: [CalendarEntry] = []
    var isLoading = false
    var error: String?

    // MARK: - Data Loading
    func loadCalendarData() async {
        guard APIController.shared.isAuthenticated else {
            error = "Please log in to view the calendar"
            return
        }
        
        isLoading = true
        error = nil
        
        defer { isLoading = false }
        
        do {
            let response = try await APIController.shared.fetchAllCalendarEntries()
            calendarEntries = response.map { CalendarEntry(from: $0) }
        } catch {
            error = "Failed to load calendar: \(error.localizedDescription)"
        }
    }
    
    // MARK: - Helper Methods
    func entriesForMonth(year: Int, month: Int) -> [CalendarEntry] {
        calendarEntries.filter { entry in
            let components = Calendar.current.dateComponents([.year, .month], from: entry.date)
            return components.year == year && components.month == month
        }
    }
    
    func entryForDate(_ date: Date) -> CalendarEntry? {
        calendarEntries.first { Calendar.current.isDate($0.date, inSameDayAs: date) }
    }
}
