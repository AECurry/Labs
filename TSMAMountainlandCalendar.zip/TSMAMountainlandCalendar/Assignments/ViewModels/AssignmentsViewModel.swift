//
//  AssignmentViewModel.swift
//  TSMAMountainlandCalendar
//
//  Created by AnnElaine on 11/7/25.
//

import Foundation
import Observation

// MARK: - Assignment ViewModel
/// Manages assignment data, loading, and state for the assignments screen
/// Acts as the bridge between the API data and the user interface
/// Follows MVVM architecture by separating data logic from presentation
@Observable
class AssignmentViewModel {
    // MARK: - Properties
    /// All assignments loaded from the API, converted to our internal model
    var assignments: [Assignment] = []
    
    /// Tracks whether data is currently being loaded from the server
    /// Controls loading indicators and prevents duplicate requests
    var isLoading = false
    
    /// Stores error messages for display when API calls fail
    /// Provides user-friendly error feedback for network issues
    var error: String?
    
    // MARK: - Data Loading
    /// Fetches all assignments from the API and converts them to our model
    /// Handles authentication checks, loading states, and error management
    func loadAssignments() async {
        isLoading = true
        error = nil
        
        defer { isLoading = false }
        
        guard APIController.shared.isAuthenticated else {
            error = "Please log in to view assignments"
            return
        }
        
        do {
            // Fetch assignments from API with progress tracking and FAQs included
            let apiAssignments = try await APIController.shared.fetchAllAssignments()
            
            // Convert API DTOs to our internal Assignment model
            assignments = apiAssignments.map { apiAssignment in
                // Determine completion date based on userProgress
                var completionDate: Date? = nil
                if apiAssignment.userProgress == "complete" {
                    completionDate = Date() // Use current date for completed assignments
                }
                
                // Map API assignment type to our internal enum
                let assignmentType = Assignment.AssignmentType.from(apiType: apiAssignment.assignmentType)
                
                // Create Assignment instance
                return Assignment(
                    assignmentID: apiAssignment.id.uuidString,
                    title: apiAssignment.name,
                    dueDate: apiAssignment.dueOn,
                    lessonID: apiAssignment.id.uuidString, // Using assignment ID as fallback for lesson ID
                    assignmentType: assignmentType,
                    markdownDescription: apiAssignment.body,
                    completionDate: completionDate
                )
            }
            
        } catch {
            self.error = "Failed to load assignments: \(error.localizedDescription)"
            print("Assignment load error: \(error)")
        }
    }
    
    // MARK: - Assignment Management
    /// Toggles the completion status of an assignment via API
    /// Updates local state after successful API call for immediate UI feedback
    func toggleAssignmentCompletion(_ assignment: Assignment) async -> Bool {
        let newProgress = assignment.isCompleted ? "notStarted" : "complete"
        
        guard let assignmentUUID = UUID(uuidString: assignment.assignmentID) else {
            error = "Invalid assignment identifier"
            return false
        }
        
        do {
            // Submit progress update to API
            let updatedDTO = try await APIController.shared.submitAssignmentProgress(
                assignmentID: assignmentUUID,
                progress: newProgress
            )
            
            // Convert updated DTO back to our model
            var updatedAssignment = assignment
            updatedAssignment.completionDate = (newProgress == "complete") ? Date() : nil
            
            // Update in our local array
            if let index = assignments.firstIndex(where: { $0.assignmentID == assignment.assignmentID }) {
                assignments[index] = updatedAssignment
            }
            
            return true
        } catch {
            self.error = "Failed to update assignment: \(error.localizedDescription)"
            print("Assignment progress update error: \(error)")
            return false
        }
    }
    
    // MARK: - Filter Methods
    /// Organizes assignments by their current status for display
    /// Provides categorized data for the assignments list view
    func assignmentsByStatus() -> (overdue: [Assignment],
                                   upcoming: [Assignment],
                                   completed: [Assignment]) {
        let now = Date()
        
        let overdue = assignments.filter { $0.isOverdue }
        let completed = assignments.filter { $0.isCompleted }
        let upcoming = assignments.filter { !$0.isCompleted && !$0.isOverdue }
        
        return (overdue, upcoming, completed)
    }
}
