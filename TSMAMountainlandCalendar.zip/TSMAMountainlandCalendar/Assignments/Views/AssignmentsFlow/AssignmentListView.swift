//
//  AssignmentListView.swift
//  TSMAMountainlandCalendar
//
//  Created by AnnElaine on 11/7/25.
//

import SwiftUI

// MARK: - Assignment List View
/// Displays a simple list of assignments loaded from the API
/// Organizes assignments by status with clear visual grouping
struct AssignmentListView: View {
    // MARK: - Properties
    let currentUser: Student
    let assignments: [Assignment]
    @Environment(\.dismiss) private var dismiss
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // MARK: - Header
                headerView
                
                // MARK: - Content
                contentView
            }
            .background(MountainlandColors.platinum.ignoresSafeArea())
            .navigationBarHidden(true)
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        HStack {
            Button(action: { dismiss() }) {
                Image(systemName: "chevron.left")
                    .font(.title3)
                    .foregroundColor(.primary)
            }
            .padding(.leading, 8)
            
            Spacer()
            
            UserProfileCircle(initials: currentUser.initials, size: 40)
                .padding(.trailing, 8)
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .padding(.bottom, 16)
    }
    
    // MARK: - Content View
    private var contentView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // MARK: - Title
                VStack(alignment: .leading, spacing: 4) {
                    Text("All Assignments")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(MountainlandColors.smokeyBlack)
                    
                    Text("Organized by status")
                        .font(.subheadline)
                        .foregroundColor(MountainlandColors.battleshipGray)
                }
                .padding(.horizontal, 24)
                .padding(.top, 8)
                
                // MARK: - Assignments Card
                VStack(spacing: 0) {
                    // Overdue Section
                    if !overdueAssignments.isEmpty {
                        AssignmentSection(title: "Overdue", assignments: overdueAssignments)
                    }
                    
                    // Upcoming Section
                    if !upcomingAssignments.isEmpty {
                        AssignmentSection(title: "Upcoming", assignments: upcomingAssignments)
                    }
                    
                    // Completed Section
                    if !completedAssignments.isEmpty {
                        AssignmentSection(title: "Completed", assignments: completedAssignments)
                    }
                    
                    // Empty State
                    if assignments.isEmpty {
                        emptyStateView
                    }
                }
                .background(MountainlandColors.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.1), radius: 3, x: 0, y: 2)
                .padding(.horizontal, 16)
            }
            .padding(.bottom, 24)
        }
    }
    
    // MARK: - Assignment Section
    private func AssignmentSection(title: String, assignments: [Assignment]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(MountainlandColors.smokeyBlack)
                .padding(.horizontal, 16)
                .padding(.top, 16)
            
            ForEach(assignments) { assignment in
                AssignmentRowView(
                    assignment: assignment,
                    onToggleComplete: {
                        // This would need to be connected to a ViewModel
                        // For now, we'll leave it empty
                    },
                    onTap: {
                        // Show assignment details
                    }
                )
                .padding(.horizontal, 16)
            }
        }
    }
    
    // MARK: - Empty State
    private var emptyStateView: some View {
        VStack {
            Text("No Assignments")
                .font(.headline)
                .foregroundColor(.secondary)
                .padding()
            Text("You don't have any assignments at this time.")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.vertical, 40)
    }
    
    // MARK: - Computed Properties
    private var overdueAssignments: [Assignment] {
        assignments.filter { $0.isOverdue }
    }
    
    private var upcomingAssignments: [Assignment] {
        assignments.filter { !$0.isCompleted && !$0.isOverdue }
    }
    
    private var completedAssignments: [Assignment] {
        assignments.filter { $0.isCompleted }
    }
}

// MARK: - User Profile Circle
struct UserProfileCircle: View {
    let initials: String
    let size: CGFloat
    
    var body: some View {
        ZStack {
            Circle()
                .fill(MountainlandColors.burgundy2)
                .frame(width: size, height: size)
            
            Text(initials)
                .font(.system(size: size * 0.4, weight: .bold))
                .foregroundColor(.white)
        }
    }
}

// MARK: - Preview
#Preview {
    AssignmentListView(
        currentUser: Student.demoStudents[0],
        assignments: [
            Assignment.placeholder,
            Assignment(
                assignmentID: "TP02",
                title: "List.Form Lab",
                dueDate: Date().addingTimeInterval(86400),
                lessonID: "02",
                assignmentType: .lab,
                markdownDescription: "# List.Form Lab",
                completionDate: nil
            )
        ]
    )
}
