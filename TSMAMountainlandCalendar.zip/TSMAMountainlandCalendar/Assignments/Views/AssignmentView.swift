//
//  AssignmentView.swift
//  TSMAMountainlandCalendar
//
//  Created by AnnElaine on 11/7/25.
//

import SwiftUI

// MARK: - Assignment View
/// Main assignments screen that displays all assignments from the API
/// Shows assignments organized by status (overdue, upcoming, completed)
/// Provides a clean, intuitive interface for assignment management
struct AssignmentView: View {
    // MARK: - Properties
    /// Current user for personalized display and authentication context
    let currentUser: Student
    
    /// ViewModel that manages assignment data and API interactions
    @State private var viewModel = AssignmentViewModel()
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // MARK: - App Header
                /// Consistent header across all tabs with course information
                AppHeader(
                    title: "iOS Development",
                    subtitle: "Fall/Spring - 25/26"
                )
                
                // MARK: - Content Area
                /// Dynamically shows loading, error, or assignment content
                contentView
            }
            .background(MountainlandColors.platinum.ignoresSafeArea())
            .task {
                await viewModel.loadAssignments()
            }
        }
    }
    
    // MARK: - Content View
    /// Dynamically switches between loading, error, and assignment list states
    @ViewBuilder
    private var contentView: some View {
        if viewModel.isLoading {
            loadingView
        } else if let error = viewModel.error {
            errorView(error)
        } else {
            AssignmentListView(
                currentUser: currentUser,
                assignments: viewModel.assignments
            )
        }
    }
    
    // MARK: - Loading State
    /// Shows progress indicator while assignments are loading
    /// Provides visual feedback during network requests
    private var loadingView: some View {
        ProgressView("Loading assignments...")
            .padding()
            .frame(maxHeight: .infinity)
    }
    
    // MARK: - Error State
    /// Displays error message and retry button when loading fails
    /// Helps users recover from network or server issues
    private func errorView(_ error: String) -> some View {
        VStack {
            Text("Error Loading Assignments")
                .font(.headline)
                .padding()
            
            Text(error)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding()
            
            Button("Retry") {
                Task { await viewModel.loadAssignments() }
            }
            .padding()
        }
        .frame(maxHeight: .infinity)
    }
}

// MARK: - Preview
/// Xcode preview for design and layout testing
/// Shows the assignment view with sample student data
#Preview {
    AssignmentView(currentUser: Student.demoStudents[0])
}
